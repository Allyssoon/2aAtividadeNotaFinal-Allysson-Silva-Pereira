<?php
require 'database.php';
$db = getDB();

$id = $_GET['id'];
$status = $_GET['status'];

$db->exec("UPDATE tarefas SET concluida = $status WHERE id = $id");

header("Location: index.php");
exit;
?>
