<?php
require 'database.php';
$db = getDB();

$id = $_GET['id'];

$db->exec("DELETE FROM tarefas WHERE id = $id");

header("Location: index.php");
exit;
?>
