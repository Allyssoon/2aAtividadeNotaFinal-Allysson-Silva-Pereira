<?php
function getDB() {
    $db = new SQLite3('tarefas.db');

    
    $db->exec("CREATE TABLE IF NOT EXISTS tarefas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        descricao TEXT NOT NULL,
        data TEXT NOT NULL
    )");

    
    $results = $db->query("PRAGMA table_info(tarefas)");
    $colunas = [];
    while ($col = $results->fetchArray(SQLITE3_ASSOC)) {
        $colunas[] = $col['name'];
    }

    if (!in_array("concluida", $colunas)) {
        $db->exec("ALTER TABLE tarefas ADD COLUMN concluida INTEGER DEFAULT 0");
    }

    return $db;
}
?>
