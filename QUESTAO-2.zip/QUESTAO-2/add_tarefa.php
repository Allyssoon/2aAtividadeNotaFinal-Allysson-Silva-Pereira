<?php
require 'database.php';
$db = getDB();

$descricao = $_POST['descricao'];
$data = $_POST['data'];

$stmt = $db->prepare("INSERT INTO tarefas (descricao, data) VALUES (:descricao, :data)");
$stmt->bindValue(':descricao', $descricao, SQLITE3_TEXT);
$stmt->bindValue(':data', $data, SQLITE3_TEXT);
$stmt->execute();

header("Location: index.php");
exit;
?>
