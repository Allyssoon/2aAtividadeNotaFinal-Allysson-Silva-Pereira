<?php
require 'database.php'; 
$lista = $db->query("SELECT * FROM livros ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteca</title>
    <meta name="author" content="Allysson Silva Pereira  - Matrícula: 201708296824" />
    <meta name="description" content="Banco de Dados Livraria.">
    <style>
    body{
        background: #f0f0f5;
        font-family: Arial, Helvetica, sans-serif;
        margin: 0;
        padding: 0;
    }

    h1, h2 {
        text-align: center;
        color: #333;
    }

    form {
        text-align: center;
        background: white;
        width: 80%;
        margin: 20px auto;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }

    form label {
        font-weight: bold;
        margin-right: 5px;
    }

    input[type="text"],
    input[type="number"] {
        padding: 8px;
        margin: 5px;
        border: 1px solid #aaa;
        border-radius: 5px;
        width: 180px;
    }

    input[type="submit"] {
        padding: 10px 20px;
        background: #010df7ff;
        border: none;
        border-radius: 6px;
        color: white;
        font-weight: bold;
        cursor: pointer;
        transition: 0.2s;
        margin-top: 10px;
    }

    input[type="submit"]:hover {
        background: #010df7ff;
        transform: scale(1.05);
    }

    table {
        width: 80%;
        margin: 20px auto;
        border-collapse: collapse;
        background: white;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }

    th {
        background: #010df7ff;
        color: white;
        padding: 12px;
    }

    td {
        padding: 10px;
        border-bottom: 1px solid #ddd;
        text-align: center;
    }

    tr:hover {
        background: #f5f5f5;
    }

    a {
        color: #d9534f;
        font-weight: bold;
        text-decoration: none;
        padding: 10px:
    }

    
    
</style>


    
</head>
<body>

<h1>Tudo sobre livros</h1>

<form action="add_book.php" method="POST">
    <label>Título:</label>
    <input type="text" name="titulo">

    <label>Autor do Livro:</label>
    <input type="text" name="autor">

    <label>Ano do Livro:</label>
    <input type="number" name="ano">

    <input type="submit" onclick="return confirm('Confirmar o cadastro deste livro?');" value="Salvar">
    
</form>

<hr>

<h2>Livros cadastrados</h2>

<table border="1" cellpadding="8">
    <tr>
        <th>Título</th>
        <th>Autor</th>
        <th>Ano</th>
    </tr>

    <?php while ($row = $lista->fetchArray(SQLITE3_ASSOC)) { ?>
        <tr>
        
            <td><?= $row['titulo'] ?></td>
            <td><?= $row['autor'] ?></td>
            <td><?= $row['ano'] ?></td>
            <td>
                <a class="btn-excluir" href="delete_book.php?id=<?= $row['id'] ?>" 
                    onclick="return confirm('Tem certeza que deseja excluir este livro?');">Excluir</a>
            </td>    
                
        </tr>
    <?php } ?>
</table>

</body>
</html>
