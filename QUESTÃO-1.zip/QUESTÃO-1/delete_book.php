<?php

require 'database.php';


if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    
    $id = (int) $_GET['id'];

    
    $sql = "DELETE FROM livros WHERE id = :id";
    
    
    
    $stmt = $db->prepare("DELETE FROM livros WHERE id = :id");
    $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
    $stmt->execute();

    
    header('Location: index.php');
    exit;

} else {
  
    header('Location: index.php');
    exit;
}
?>