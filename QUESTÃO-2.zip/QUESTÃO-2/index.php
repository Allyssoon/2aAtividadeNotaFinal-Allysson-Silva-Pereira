<?php
require 'database.php';
$db = getDB();

// Filtro
$filtro = isset($_GET['filtro']) ? $_GET['filtro'] : '';

if ($filtro === "1") {
    $lista = $db->query("SELECT * FROM tarefas WHERE concluida = 1 ORDER BY data ASC");
} elseif ($filtro === "0") {
    $lista = $db->query("SELECT * FROM tarefas WHERE concluida = 0 ORDER BY data ASC");
} else {
    $lista = $db->query("SELECT * FROM tarefas ORDER BY data ASC");
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Tarefas</title>
    <meta name="author" content="Allysson Silva Pereira  - Matrícula: 201708296824" />
    <meta name="description" content="Sistema de Gerenciamento de Tarefas.">
    <style>
        
    body{
        background: #f0f0f5;
        font-family: Arial, Helvetica, sans-serif;
        margin: 0;
        padding: 0;
    }

    h1, h2 {
        text-align: center;
        color: #333;
    }

    form {
        text-align: center;
        background: white;
        width: 80%;
        margin: 20px auto;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }

    form label {
        font-weight: bold;
        margin-right: 5px;
    }

    input[type="text"],
    input[type="number"] {
        padding: 8px;
        margin: 5px;
        border: 1px solid #aaa;
        border-radius: 5px;
        width: 180px;
    }

    input[type="submit"] {
        padding: 10px 20px;
        background: #4CAF50;
        border: none;
        border-radius: 6px;
        color: white;
        font-weight: bold;
        cursor: pointer;
        transition: 0.2s;
        margin-top: 10px;
    }

    input[type="submit"]:hover {
        background: #45a049;
        transform: scale(1.05);
    }

    table {
        width: 80%;
        margin: 20px auto;
        border-collapse: collapse;
        background: white;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }

    th {
        background: #4CAF50;
        color: white;
        padding: 12px;
    }

    td {
        padding: 10px;
        border-bottom: 1px solid #ddd;
        text-align: center;
    }

    tr:hover {
        background: #f5f5f5;
    }

    a {
        color: #d9534f;
        font-weight: bold;
        text-decoration: none;
        padding: 10px:
    }

    
    
</style>    

</head>
<body>

<h1>Gerenciamento de Tarefas</h1>


<form action="add_tarefa.php" method="POST">
    <label for="descricao">Descrição:</label>
    <input type="text" id="descricao" name="descricao" required>

    <label for="data">Data de vencimento:</label>
    <input type="date" id="data" name="data" required>

    <input type="submit" value="Salvar"
           onclick="return confirm('Confirmar o cadastro desta tarefa?');">
</form>

<hr>


<form method="GET" action="">
    <label>Filtrar por:</label>
    <select name="filtro" onchange="this.form.submit()">
        <option value="">Todas</option>
        <option value="1" <?= ($filtro === "1") ? "selected" : "" ?>>Concluídas</option>
        <option value="0" <?= ($filtro === "0") ? "selected" : "" ?>>Não concluídas</option>
    </select>
</form>

<hr>

<h2>Tarefas</h2>

<table border="1" cellpadding="8">
    <tr>
        <th>Concluída</th>
        <th>Descrição</th>
        <th>Data</th>
        <th>Ações</th>
    </tr>

    <?php while ($row = $lista->fetchArray(SQLITE3_ASSOC)) { ?>
        <tr>
            <td>
                <input type="checkbox"
                       onchange="window.location.href='update_tarefa.php?id=<?= $row['id'] ?>&status=<?= $row['concluida'] ? 0 : 1 ?>'"
                       <?= $row['concluida'] ? 'checked' : '' ?>>
            </td>

            <td style="<?= $row['concluida'] ? 'text-decoration: line-through; color: gray;' : '' ?>">
                <?= htmlspecialchars($row['descricao']) ?>
            </td>

            <td><?= htmlspecialchars($row['data']) ?></td>

            <td>
                <a href="delete_tarefa.php?id=<?= $row['id'] ?>"
                   onclick="return confirm('Tem certeza que deseja excluir?');">Excluir</a>
            </td>
        </tr>
    <?php } ?>
</table>

</body>
</html>
