<?php
require 'database.php'; 

$titulo = $_POST['titulo'] ?? '';
$autor  = $_POST['autor'] ?? '';
$ano    = $_POST['ano'] ?? '';

if (!empty($titulo)) {
    $stmt = $db->prepare("INSERT INTO livros (titulo, autor, ano) VALUES (:titulo, :autor, :ano)");
    $stmt->bindValue(':titulo', $titulo, SQLITE3_TEXT);
    $stmt->bindValue(':autor', $autor, SQLITE3_TEXT);
    $stmt->bindValue(':ano', $ano, SQLITE3_INTEGER);
    $stmt->execute();
}


header("Location: index.php");
exit;
?>
